/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package adapter;

/**
 *
 * @author placi
 */
public class Matematica  {
    public static double raiz(double d){
        return Math.sqrt(d);
    }

    public static double maximo(int i, int j, int k, int l){
        return Math.max(Math.max(i, j),Math.max(k, l));
    }    
    


}
