/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package decorator;


/**
 *
 * @author placi
 */
public class CarroBasico implements Carro{

    @Override
    public double getCusto() {
        return 300000;
    }

    @Override
    public String getComponentes() {
        return "Carro Básico";
    }
    
    
}
