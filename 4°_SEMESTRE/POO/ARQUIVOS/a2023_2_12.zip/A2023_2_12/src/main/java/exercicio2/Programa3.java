/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicio2;

/**
 *
 * @author placi
 */
public class Programa3 {
    public static void main(String[] args) {
        Impressora imp = new Impressora();
        imp.imprimirCabealho(new UVA());
        imp.imprimirRodape(new UECE());
        imp.imprimirCabealho(new UNIFOR());
        imp.imprimirRodape(new UNIFOR());
        
        
    }
    
}
