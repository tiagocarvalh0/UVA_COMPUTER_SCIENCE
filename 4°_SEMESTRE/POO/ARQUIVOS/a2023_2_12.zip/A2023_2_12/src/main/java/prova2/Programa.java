/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prova2;

/**
 *
 * @author placi
 */
public class Programa {
    public static void main(String[] args) {
        CachorroQuente cq = new Maionese(new PaoSalsicha());
        //cq = new PaoSalsicha();

        System.out.println(cq.getDescricao());
        
    }
    
}
