/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicio2;

/**
 *
 * @author placi
 */
public class UVA implements Imprimivel{
    public void imprimirCabecalho(){
        System.out.println("Universidade Estadual Vale do Acaráu");
        
    }
    public void imprimirRodape(){
        System.out.println("---------------------- UVA ----------------------------");
    }
    
    
}
