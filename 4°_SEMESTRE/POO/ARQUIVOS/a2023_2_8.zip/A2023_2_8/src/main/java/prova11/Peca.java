/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prova11;


/**
 *
 * @author placi
 */
public class Peca extends Item{
    public Peca() {
    }

    public Peca(String nome, double valor) {
        super(nome,valor);
    }
    
    
}
