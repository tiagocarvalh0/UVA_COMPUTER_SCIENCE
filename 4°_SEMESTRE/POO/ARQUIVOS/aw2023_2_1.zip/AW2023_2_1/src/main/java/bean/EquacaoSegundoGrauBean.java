/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.io.Serializable;
import javax.enterprise.context.SessionScoped;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;

import modelo.EquacaoSegundoGrau;
import modelo.EquacaoSegundoGrauException;

@Named("equacaoSegundoGrauBean")
@SessionScoped
public class EquacaoSegundoGrauBean implements Serializable{

    private EquacaoSegundoGrau equacao = new EquacaoSegundoGrau();

    public EquacaoSegundoGrau getEquacao(){
        return equacao;
    }

    private double x1=0;
    private double x2=0;
    private boolean real=true;

    public boolean isReal() {
        return real;
    }

    public void setReal(boolean real) {
        this.real = real;
    }
    



    public void setEquacao(EquacaoSegundoGrau equacao) {
        this.equacao = equacao;
    }

    public void submeter() {
        try {
            x1 = equacao.x1();
            x2 = equacao.x2();
            real=true;
        } catch (EquacaoSegundoGrauException e) {
            x1=0;
            x2=0;
            real=false;
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Nao existe raizes reais", ""));
        }
    }


    public double getX1() {
      return x1;
    }

    
    public double getX2() {
       return x2;
    }





}
