/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.inject.Named;
import modelo.Curso;

/**
 *
 * @author placi
 */
@Named("cursosBean")
@SessionScoped
public class CursosBean implements Serializable {

    private List<Curso> cursos = new ArrayList<Curso>();
    private Curso curso = new Curso();
    private boolean alterar = false;
    private int posicaoAlterar = -1;
    private boolean novo = true;
    
    
    public List<Curso> getCursos() {
        return cursos;
    }

    public String nomeBotao() {
        if (alterar) {
            return "Salvar";
        } else {
            return "Adicionar";
        }
    }
    
    public boolean novoHabilitado() {
        return novo;
    }

    public Curso prepareCreate() {
        curso = new Curso();
        novo=false;
//        initializeEmbeddableKey();
        return curso;
    }

    public String cancelar() {
        System.out.println("cancelar");
        this.curso = null;
        alterar = false;
        novo=true;
        return "cursos";
    }

    public void adicionaCurso() {
        if (alterar) {
            this.cursos.set(posicaoAlterar, curso);
        } else {
            this.cursos.add(this.curso);
            
        }
            
        novo=true;
        alterar = false;
        this.curso = new Curso();
    }

    public void removeCurso(Curso curso) {
        this.cursos.remove(curso);
        System.out.println("removeu");
    }

    public void carregar(Curso curso) {
        posicaoAlterar = cursos.indexOf(curso);
        this.curso = clone(curso);
        alterar = true;
        novo=false;
    }

    public Curso getCurso() {
        return curso;
    }

    public Curso clone(Curso curso){
        Curso cursoClone = new Curso();
        cursoClone.setNome(curso.getNome());
        cursoClone.setSigla(curso.getSigla());
        cursoClone.setCentro(curso.getCentro());
        cursoClone.setTurno(curso.getTurno());
        return cursoClone;
    }
    
    
    public Curso getCurso(String nome) {
        Curso cursoSearch = null;
        for (Curso c : cursos) {
            if (c.getNome().equals(nome)) {
                cursoSearch = c;
            }
        }
        return cursoSearch;
    }

    // GETTER E SETTER
    @FacesConverter(forClass = Curso.class)
    public static class CursoBeanConverter implements Converter {

        @Override
        public Object getAsObject(FacesContext facesContext, UIComponent component, String value) {
            if (value == null || value.length() == 0) {
                return null;
            }
            CursosBean controller = (CursosBean) facesContext.getApplication().getELResolver().
                    getValue(facesContext.getELContext(), null, "cursosBean");
            return controller.getCurso(value);
        }

        @Override
        public String getAsString(FacesContext facesContext, UIComponent component, Object object) {
            return ((Curso) object).getNome();
        }

    }

}
