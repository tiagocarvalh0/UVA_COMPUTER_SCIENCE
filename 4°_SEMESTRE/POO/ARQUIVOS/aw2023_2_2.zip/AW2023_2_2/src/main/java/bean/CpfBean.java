/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.io.Serializable;
import javax.enterprise.context.SessionScoped;
import javax.faces.bean.ManagedBean;
import javax.inject.Named;
import modelo.Cpf;

/**
 *
 * @author placido
 */
@Named("cpfBean")
@SessionScoped
public class CpfBean implements Serializable {

    private String numCpf;

    public void setNumCpf(String c) {
        numCpf = c;
    }

    public String getNumCpf() {
        return numCpf;
    }

    public String statusCpf() {
        if (Cpf.validaCPF(numCpf)) {
            setNumCpf("");
            return "CPF OK";

        } else {
            setNumCpf("");
            return "CPF ERRADO";
        }

    }
}
