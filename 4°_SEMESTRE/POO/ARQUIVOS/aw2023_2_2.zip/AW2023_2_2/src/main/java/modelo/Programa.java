/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author placi
 */
public class Programa {

    public static void main(String[] args) throws EquacaoSegundoGrauException {
        Dado d = new Dado();
        System.out.println(d.joga());
        Texto t = new Texto();
        t.setTexto("universidade");
        System.out.println(t.contagem());
        Mulher m = new Mulher();
        m.acrescentar();
        m.acrescentar();
        EquacaoSegundoGrau eq = new EquacaoSegundoGrau();
        eq.setA(-1);
        eq.setB(2);
        eq.setC(3);
        try {
            System.out.println(eq.x1());
            System.out.println(eq.x2());
            
        } catch (EquacaoSegundoGrauException e) {
            System.out.println("nao existe raizes reais");

        }
    }

}
