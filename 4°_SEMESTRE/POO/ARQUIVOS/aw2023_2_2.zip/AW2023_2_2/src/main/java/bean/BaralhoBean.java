/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.io.Serializable;
import java.util.ArrayList;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;
import modelo.Baralho;
import modelo.BaralhoGenerico;
import modelo.Carta;

/**
 *
 * @author placi
 */
@Named("baralhoBean")
@SessionScoped
public class BaralhoBean implements Serializable {
    Baralho b = new Baralho();

    public Baralho getBaralho() {
        return b;
    }
    
    public Baralho criarBaralho(){
        b = new Baralho();
        b.getBaralho();
        return b;
    }
    
    /*
    public void virar(Carta carta){
        carta.virar();
    }
    */      
    
    
}
