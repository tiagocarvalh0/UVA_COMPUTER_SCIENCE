/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.enterprise.context.SessionScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.FacesConverter;
import javax.inject.Named;
import modelo.Curso;
import modelo.Professor;

/**
 *
 * @author placi
 */
@Named("professorBean")
@SessionScoped
public class ProfessorBean implements Serializable {

    Curso curso = new Curso();
    private Professor professor = new Professor();
    private int posicaoAlterar = -1;
    private List<Professor> professores = new ArrayList<Professor>();
    private boolean novo = true;

    public ProfessorBean() {
    }

    private boolean alterar = false;

    public Professor getProfessor() {
        return professor;
    }

    public void setProfessor(Professor professor) {
        this.professor = professor;
    }

    public List<Professor> getProfessores() {
        return professores;
    }

    public boolean novoHabilitado() {
        return novo;
    }

    public Professor prepareCreate() {
        professor = new Professor();
        novo = false;
        return professor;
    }

    public void adicionaProfessor() {

        if (alterar) {
            this.professores.set(posicaoAlterar, professor);
        } else {
            this.professores.add(professor);
        }
        novo = true;
        alterar = false;

    }

    public String cancelar() {
        this.professor = new Professor();
        alterar = false;
        novo = true;
        return "professores";
    }

    public void removeProfessor(Professor professor) {
        this.professores.remove(professor);
        System.out.println("removeu");
    }

    public void carregar(Professor professor) {
        posicaoAlterar = professores.indexOf(professor);
        this.professor = clone(professor);
        alterar = true;
        novo = false;
    }

    public Professor clone(Professor professor) {
        Professor professorClone = new Professor();
        professorClone.setNome(professor.getNome());
        professorClone.setCurso(professor.getCurso());
        return professorClone;
    }

    public Professor getProfessor(String nome) {
        Professor professorSearch = null;
        for (Professor p : professores) {
            if (p.getNome().equals(nome)) {
                professorSearch = p;
            }
        }
        return professorSearch;
    }

    @FacesConverter(forClass = Professor.class)
    public static class ProfessorBeanConverter implements Converter {

        @Override
        public Object getAsObject(FacesContext facesContext, UIComponent component, String value) {
            if (value == null || value.length() == 0) {
                return null;
            }
            ProfessorBean controller = (ProfessorBean) facesContext.getApplication().getELResolver().
                    getValue(facesContext.getELContext(), null, "professorBean");
            return controller.getProfessor(value);
        }

        @Override
        public String getAsString(FacesContext facesContext, UIComponent component, Object object) {
            return ((Professor) object).getNome();
        }

    }

}
