/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package fac;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author placi
 */
public class Program1 {

    public static void main(String[] args) {
        ArrayList<String> numbers = new ArrayList();
        numbers.add("aaa");
        numbers.add("bbb");
        numbers.add("ccc");
        numbers.add("dddd");
        
        ListIterator lit = numbers.listIterator();
        lit.a
        lit.add("xxx");
        lit.next();
        lit.next();
        lit.next();
        lit.next();
        lit.next();
        lit.next();
        lit.next();
        
        System.out.println(numbers);
        System.out.println(lit.next());
        Iterator<String> it = numbers.iterator();
        System.out.println(numbers);
        
        while (it.hasNext()) {
            String i = it.next();
            if (i.equals("bbb")) {
                it.remove();
            }
        }
        System.out.println(numbers);
        for (String s : numbers) {
            if (s.equals("ccc")) {
                numbers.remove(s);
            }
        }
        System.out.println(numbers);
        Set<String> cargos = new HashSet();
        Map<String, String> mapas = new HashMap();
        System.out.println(numbers);
        
        
        
        
    }
}
