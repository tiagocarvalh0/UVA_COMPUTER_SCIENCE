/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exercicio2;

/**
 *
 * @author placi
 */
public class Impressora {
    public void imprimirCabealho(Imprimivel i){
        i.imprimirCabecalho();
        
    }
    public void imprimirRodape(Imprimivel i){
        i.imprimirRodape();
    }
    
}
