/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ite;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Vector;

/**
 *
 * @author placi
 */
public class Programa {
    public static void main(String[] args) {
        ArrayList<String> lista = new ArrayList();
        LinkedList<String> lista1 = new LinkedList();
        Vector<String> lista2 = new Vector();
        
        Iterator
        
        lista2.add("xxx");
        ListaIterator li = new ListaIterator(lista2);
        System.out.println(li.get(0));
        li.set("aaaa");
        System.out.println(li.get(0));
        System.out.println(lista2);
        System.out.println(li.hasNext());
        System.out.println(li.hasPrevious());
        li.add("ffff");
        System.out.println(li);
        
        
    }
    
}
