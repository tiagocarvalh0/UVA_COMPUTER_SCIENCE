/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula2;

/**
 *
 * @author placi
 */
public class Programa2 {
    public static void main(String[] args) {
        Equacao2Grau eq = new Equacao2Grau(-2,3,4);
        System.out.println(eq.x1());
        System.out.println(eq.x2());
        
    }
}
