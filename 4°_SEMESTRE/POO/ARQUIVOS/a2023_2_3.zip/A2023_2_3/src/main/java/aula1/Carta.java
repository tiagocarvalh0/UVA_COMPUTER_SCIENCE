/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package aula1;

/**
 *
 * @author placi
 */
public class Carta {
    private String naipe,valor;

    public String getNaipe() {
        return naipe;
    }

    public void setNaipe(String naipe) {
        
        this.naipe = naipe;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }
    
   
}
