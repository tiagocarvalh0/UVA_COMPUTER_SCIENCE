/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package exercicio1;

/**
 *
 * @author placi
 */
public interface Gratificacao {
    public double calculo(double salario);
}
