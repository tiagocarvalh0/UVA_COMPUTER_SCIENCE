/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.agendamento;
import com.mycompany.agendamento.OBJ.*;
/**
 *
 * @author Tiago
 */
public class Agendamento {
    public static void main(String args[]) {
        
        Motorista motorista = new Motorista("José Pereira", "987.654.321-00");
        Veiculo veiculo = new Veiculo("FIAT", "MOBI", "SBK-4J41", 4);
        
        Endereco x = new Endereco("R. Isaias Macahdo Portela","Centro", "351");
        Pessoa p = new Pessoa("Tiago da Costa Carvalho", "087.750.833-02", "(88) 98124-9593", x);
        Pessoa a1 = new Pessoa("Lucas Thiago Thiago Teixeira", "070.213.377-95", "(21) 3527-5078", x);
        Pessoa a2 = new Pessoa("Caio Guilherme Bryan Barbosa", "867.992.609-46", "(86) 2734-3086", x);
        Pessoa a3 = new Pessoa("Paulo Gael Oliveira", "451.972.688-32", "(84) 3679-4389", x);
        
        Endereco y1 = new Endereco("Av. Principal", "Bairro Novo", "12345");
        Pessoa p2 = new Pessoa("João da Silva", "123.456.789-10", "(11) 98765-4321", y1);
        Pessoa a4 = new Pessoa("Maria Oliveira", "987.654.321-00", "(22) 1234-5678", y1);
        Pessoa a5 = new Pessoa("Pedro Santos", "111.222.333-44", "(33) 9876-5432", y1);
        Pessoa a6 = new Pessoa("Ana Souza", "555.666.777-88", "(44) 5678-1234", y1);
        
        Passageiro w = new Passageiro(p);
        w.addAcompanhante(a1);
        w.addAcompanhante(a2);
        w.addAcompanhante(a3);
        
        Passageiro y = new Passageiro(p2);
        y.addAcompanhante(a4);
        y.addAcompanhante(a5);
        y.addAcompanhante(a6);

        Ocupantes oc = new Ocupantes();
        oc.addOcupantes(w);
        oc.addOcupantes(y);
        
        Destino destino = new Destino();
        destino.addDestino(y1);
        destino.addDestino(x);
        
        Viagem viagem = new Viagem();
        
        viagem.setMotorista(motorista);
        viagem.setVeiculo(veiculo);
        viagem.setHorarioViagem("12:00");
        viagem.setDataSaida("01/02/2020");
        viagem.setDataChegada("02/02/2020");
        viagem.setOcupantes(oc);
        viagem.printViagem();
        
        


    }
}