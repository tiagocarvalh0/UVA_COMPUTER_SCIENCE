#include <stdlib.h>

int main() {
    system("clear && gcc basex.c -o basex -lm");
}
