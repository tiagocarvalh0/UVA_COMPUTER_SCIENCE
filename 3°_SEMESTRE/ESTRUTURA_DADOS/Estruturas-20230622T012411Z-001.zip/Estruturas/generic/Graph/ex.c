#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Graph.h"

typedef struct User {
  char name[20];
  int age;
} User;

int conta_seguidos(Graph *g, char *nome);
int conta_seguidores(Graph *g, char *nome, int imprime);
Vertex *get_mais_popular(Graph *g);
int conta_segue_mais_velhos(Graph *g, int imprime);

int main() {
  char nome[20];
  Vertex *pop = NULL;
  Graph *g = Graph_alloc();
  User *uPop;
  User u[9] = {{"Joao",25},    //0
               {"Ana",23},     //1
               {"Jane",30},    //2
               {"Marcos",19},  //3
               {"Felipe",20},  //4
               {"Caio",20},    //5
               {"Pedro",20},   //6
               {"Bruna",23},   //7
               {"Renata",35}}; //8
  
  for (int i=0; i<9; i++)
    Graph_insertVertex(g, &u[i]);
  
  Graph_insertEdge(g, 0, 1, NULL);
  Graph_insertEdge(g, 0, 5, NULL);
  Graph_insertEdge(g, 0, 6, NULL);
  
  Graph_insertEdge(g, 1, 0, NULL);
  Graph_insertEdge(g, 1, 2, NULL);
  
  Graph_insertEdge(g, 2, 3, NULL);
  Graph_insertEdge(g, 2, 6, NULL);
  Graph_insertEdge(g, 2, 7, NULL);
  
  Graph_insertEdge(g, 3, 4, NULL);
  Graph_insertEdge(g, 3, 8, NULL);
  
  Graph_insertEdge(g, 4, 3, NULL);
  Graph_insertEdge(g, 4, 8, NULL);
  
  Graph_insertEdge(g, 6, 5, NULL);
  Graph_insertEdge(g, 6, 2, NULL);
  Graph_insertEdge(g, 6, 3, NULL);
  Graph_insertEdge(g, 6, 7, NULL);
  
  Graph_insertEdge(g, 7, 8, NULL);
  
  Graph_print(g);
  
  strcpy(nome, "Pedro");
  printf("Seguidos do Pedro = %d\n", conta_seguidos(g, nome));
  printf("Seguidores do Pedro = %d\n", conta_seguidores(g, nome, 1));
  
  pop = get_mais_popular(g);
  uPop = (User*) pop->value;
  printf("Mais popular = %s\n", uPop->name);  
  
  printf("So seguem mais velhos = %d\n", conta_segue_mais_velhos(g, 1));
  
  Graph_free(g);
  
  return 0;
}

int cmp(void *a, void *b) {
  User *u = (User*)a;
  char *s = (char*)b;
  
  return strcmp(u->name, s);
}

int conta_seguidos(Graph *g, char *nome) {
  Edge *e = NULL;
  Vertex *v = Graph_findVertexByValue(g, nome, cmp);
  
  if (v)
    return v->n;
  
  return 0;
}

int conta_seguidores(Graph *g, char *nome, int imprime) {
  Vertex *v0, *v1;
  Edge *e;
  int count = 0;
  User *u;
  
  v1 = Graph_findVertexByValue(g, nome, cmp);
  
  v0 = g->first;
  while (v0) {
    e = v0->first;
    
    while (e) {
      if (e->head->label == v1->label) {
        count++;
        
        if (imprime) {
          u = (User*) v0->value;
          printf("%s\n", u->name);
        }
        
        break;
      }
      e = e->next;
    }
    
    v0 = v0->next;
  }
  
  return count;
}

Vertex *get_mais_popular(Graph *g) {
  Vertex *v, *vMax;
  User *u;     
  int max, count;      
  
  vMax = g->first;
  u = (User*) vMax->value;
  max = conta_seguidores(g, u->name, 0);
  
  v = vMax->next;
  
  while (v) {
    u = (User*) v->value;
    count = conta_seguidores(g, u->name, 0);
    
    if (count > max) {
      vMax = v;
      max = count;
    }
    
    v = v->next;
  }
  
  return vMax;
}

int conta_segue_mais_velhos(Graph *g, int imprime) {
  Vertex *v;
  Edge *e;
  User *atual, *seguido;
  int count = 0;
  
  v = g->first;
  while (v) {
    atual = (User*) v->value;
    
    e = v->first;
    while (e) {
      seguido = (User*) e->head->value;
      
      if (atual->age >= seguido->age)
        break;
      
      if (e->next == NULL) {
        count++;
        if (imprime)
          printf("%s\n", atual->name);
      }
        
      e = e->next;
    }
    
    v = v->next;
  }
  
  return count;
}









